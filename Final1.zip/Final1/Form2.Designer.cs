﻿namespace Final1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnA3 = new Button();
            btnA2 = new Button();
            btnA1 = new Button();
            btnA4 = new Button();
            btnA5 = new Button();
            btnB1 = new Button();
            btnC1 = new Button();
            btnD1 = new Button();
            btnB2 = new Button();
            btnB3 = new Button();
            btnB4 = new Button();
            btnB5 = new Button();
            btnC2 = new Button();
            btnFree = new Button();
            btnC4 = new Button();
            btnC5 = new Button();
            btnD2 = new Button();
            btnD3 = new Button();
            btnD4 = new Button();
            btnD5 = new Button();
            btnE1 = new Button();
            btnE2 = new Button();
            btnE3 = new Button();
            btnE4 = new Button();
            btnE5 = new Button();
            lblCall = new Label();
            lbltreats = new Label();
            btnStart = new Button();
            btnRestart = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // btnA3
            // 
            btnA3.Location = new Point(244, 91);
            btnA3.Name = "btnA3";
            btnA3.Size = new Size(110, 103);
            btnA3.TabIndex = 2;
            btnA3.Tag = "Buttons";
            btnA3.Text = "A3";
            btnA3.UseVisualStyleBackColor = true;
            btnA3.Click += Player;
            // 
            // btnA2
            // 
            btnA2.Location = new Point(128, 91);
            btnA2.Name = "btnA2";
            btnA2.Size = new Size(110, 103);
            btnA2.TabIndex = 4;
            btnA2.Tag = "Buttons";
            btnA2.Text = "A2";
            btnA2.UseVisualStyleBackColor = true;
            btnA2.Click += Player;
            // 
            // btnA1
            // 
            btnA1.Location = new Point(12, 91);
            btnA1.Name = "btnA1";
            btnA1.Size = new Size(110, 103);
            btnA1.TabIndex = 5;
            btnA1.Tag = "Buttons";
            btnA1.Text = "A1";
            btnA1.UseVisualStyleBackColor = true;
            btnA1.Click += Player;
            // 
            // btnA4
            // 
            btnA4.Location = new Point(360, 91);
            btnA4.Name = "btnA4";
            btnA4.Size = new Size(110, 103);
            btnA4.TabIndex = 6;
            btnA4.Tag = "Buttons";
            btnA4.Text = "A4";
            btnA4.UseVisualStyleBackColor = true;
            btnA4.Click += Player;
            // 
            // btnA5
            // 
            btnA5.Location = new Point(477, 91);
            btnA5.Name = "btnA5";
            btnA5.Size = new Size(110, 103);
            btnA5.TabIndex = 7;
            btnA5.Tag = "Buttons";
            btnA5.Text = "A5";
            btnA5.UseVisualStyleBackColor = true;
            btnA5.Click += Player;
            // 
            // btnB1
            // 
            btnB1.Location = new Point(12, 200);
            btnB1.Name = "btnB1";
            btnB1.Size = new Size(110, 103);
            btnB1.TabIndex = 8;
            btnB1.Tag = "Buttons";
            btnB1.Text = "B1";
            btnB1.UseVisualStyleBackColor = true;
            btnB1.Click += Player;
            // 
            // btnC1
            // 
            btnC1.Location = new Point(12, 309);
            btnC1.Name = "btnC1";
            btnC1.Size = new Size(110, 103);
            btnC1.TabIndex = 9;
            btnC1.Tag = "Buttons";
            btnC1.Text = "C1";
            btnC1.UseVisualStyleBackColor = true;
            btnC1.Click += Player;
            // 
            // btnD1
            // 
            btnD1.Location = new Point(12, 418);
            btnD1.Name = "btnD1";
            btnD1.Size = new Size(110, 103);
            btnD1.TabIndex = 10;
            btnD1.Tag = "Buttons";
            btnD1.Text = "D1";
            btnD1.UseVisualStyleBackColor = true;
            btnD1.Click += Player;
            // 
            // btnB2
            // 
            btnB2.Location = new Point(128, 200);
            btnB2.Name = "btnB2";
            btnB2.Size = new Size(110, 103);
            btnB2.TabIndex = 11;
            btnB2.Tag = "Buttons";
            btnB2.Text = "B2";
            btnB2.UseVisualStyleBackColor = true;
            btnB2.Click += Player;
            // 
            // btnB3
            // 
            btnB3.Location = new Point(244, 200);
            btnB3.Name = "btnB3";
            btnB3.Size = new Size(110, 103);
            btnB3.TabIndex = 12;
            btnB3.Tag = "Buttons";
            btnB3.Text = "B3";
            btnB3.UseVisualStyleBackColor = true;
            btnB3.Click += Player;
            // 
            // btnB4
            // 
            btnB4.Location = new Point(360, 200);
            btnB4.Name = "btnB4";
            btnB4.Size = new Size(110, 103);
            btnB4.TabIndex = 13;
            btnB4.Tag = "Buttons";
            btnB4.Text = "B4";
            btnB4.UseVisualStyleBackColor = true;
            btnB4.Click += Player;
            // 
            // btnB5
            // 
            btnB5.Location = new Point(477, 200);
            btnB5.Name = "btnB5";
            btnB5.Size = new Size(110, 103);
            btnB5.TabIndex = 14;
            btnB5.Tag = "Buttons";
            btnB5.Text = "B5";
            btnB5.UseVisualStyleBackColor = true;
            btnB5.Click += Player;
            // 
            // btnC2
            // 
            btnC2.Location = new Point(128, 309);
            btnC2.Name = "btnC2";
            btnC2.Size = new Size(110, 103);
            btnC2.TabIndex = 15;
            btnC2.Tag = "Buttons";
            btnC2.Text = "C2";
            btnC2.UseVisualStyleBackColor = true;
            btnC2.Click += Player;
            // 
            // btnFree
            // 
            btnFree.Location = new Point(244, 309);
            btnFree.Name = "btnFree";
            btnFree.Size = new Size(110, 103);
            btnFree.TabIndex = 16;
            btnFree.Tag = "Buttons";
            btnFree.Text = "Free";
            btnFree.UseVisualStyleBackColor = true;
            btnFree.Click += Player;
            // 
            // btnC4
            // 
            btnC4.Location = new Point(360, 309);
            btnC4.Name = "btnC4";
            btnC4.Size = new Size(110, 103);
            btnC4.TabIndex = 17;
            btnC4.Tag = "Buttons";
            btnC4.Text = "C4";
            btnC4.UseVisualStyleBackColor = true;
            btnC4.Click += Player;
            // 
            // btnC5
            // 
            btnC5.Location = new Point(477, 309);
            btnC5.Name = "btnC5";
            btnC5.Size = new Size(110, 103);
            btnC5.TabIndex = 18;
            btnC5.Tag = "Buttons";
            btnC5.Text = "C5";
            btnC5.UseVisualStyleBackColor = true;
            btnC5.Click += Player;
            // 
            // btnD2
            // 
            btnD2.Location = new Point(128, 418);
            btnD2.Name = "btnD2";
            btnD2.Size = new Size(110, 103);
            btnD2.TabIndex = 19;
            btnD2.Tag = "Buttons";
            btnD2.Text = "D2";
            btnD2.UseVisualStyleBackColor = true;
            btnD2.Click += Player;
            // 
            // btnD3
            // 
            btnD3.Location = new Point(244, 418);
            btnD3.Name = "btnD3";
            btnD3.Size = new Size(110, 103);
            btnD3.TabIndex = 20;
            btnD3.Tag = "Buttons";
            btnD3.Text = "D3";
            btnD3.UseVisualStyleBackColor = true;
            btnD3.Click += Player;
            // 
            // btnD4
            // 
            btnD4.Location = new Point(360, 418);
            btnD4.Name = "btnD4";
            btnD4.Size = new Size(110, 103);
            btnD4.TabIndex = 21;
            btnD4.Tag = "Buttons";
            btnD4.Text = "D4";
            btnD4.UseVisualStyleBackColor = true;
            btnD4.Click += Player;
            // 
            // btnD5
            // 
            btnD5.Location = new Point(477, 418);
            btnD5.Name = "btnD5";
            btnD5.Size = new Size(110, 103);
            btnD5.TabIndex = 22;
            btnD5.Tag = "Buttons";
            btnD5.Text = "D5";
            btnD5.UseVisualStyleBackColor = true;
            btnD5.Click += Player;
            // 
            // btnE1
            // 
            btnE1.Location = new Point(12, 527);
            btnE1.Name = "btnE1";
            btnE1.Size = new Size(110, 103);
            btnE1.TabIndex = 23;
            btnE1.Tag = "Buttons";
            btnE1.Text = "E1";
            btnE1.UseVisualStyleBackColor = true;
            btnE1.Click += Player;
            // 
            // btnE2
            // 
            btnE2.Location = new Point(128, 527);
            btnE2.Name = "btnE2";
            btnE2.Size = new Size(110, 103);
            btnE2.TabIndex = 24;
            btnE2.Tag = "Buttons";
            btnE2.Text = "E2";
            btnE2.UseVisualStyleBackColor = true;
            btnE2.Click += Player;
            // 
            // btnE3
            // 
            btnE3.Location = new Point(244, 527);
            btnE3.Name = "btnE3";
            btnE3.Size = new Size(110, 103);
            btnE3.TabIndex = 25;
            btnE3.Tag = "Buttons";
            btnE3.Text = "E3";
            btnE3.UseVisualStyleBackColor = true;
            btnE3.Click += Player;
            // 
            // btnE4
            // 
            btnE4.Location = new Point(361, 527);
            btnE4.Name = "btnE4";
            btnE4.Size = new Size(110, 103);
            btnE4.TabIndex = 26;
            btnE4.Tag = "Buttons";
            btnE4.Text = "E4";
            btnE4.UseVisualStyleBackColor = true;
            btnE4.Click += Player;
            // 
            // btnE5
            // 
            btnE5.Location = new Point(477, 527);
            btnE5.Name = "btnE5";
            btnE5.Size = new Size(110, 103);
            btnE5.TabIndex = 27;
            btnE5.Tag = "Buttons";
            btnE5.Text = "E5";
            btnE5.UseVisualStyleBackColor = true;
            btnE5.Click += Player;
            // 
            // lblCall
            // 
            lblCall.AutoSize = true;
            lblCall.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCall.Location = new Point(203, 30);
            lblCall.Name = "lblCall";
            lblCall.Size = new Size(124, 41);
            lblCall.TabIndex = 28;
            lblCall.Text = "BINGO: ";
            // 
            // lbltreats
            // 
            lbltreats.AutoSize = true;
            lbltreats.Location = new Point(11, 10);
            lbltreats.Name = "lbltreats";
            lbltreats.Size = new Size(101, 20);
            lbltreats.TabIndex = 29;
            lbltreats.Text = "Treats Earned:";
            // 
            // btnStart
            // 
            btnStart.Location = new Point(203, 667);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(94, 29);
            btnStart.TabIndex = 30;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnRestart
            // 
            btnRestart.Location = new Point(317, 667);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(94, 29);
            btnRestart.TabIndex = 31;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = true;
            btnRestart.Click += btnRestart_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(637, 732);
            Controls.Add(btnRestart);
            Controls.Add(btnStart);
            Controls.Add(lbltreats);
            Controls.Add(lblCall);
            Controls.Add(btnE5);
            Controls.Add(btnE4);
            Controls.Add(btnE3);
            Controls.Add(btnE2);
            Controls.Add(btnE1);
            Controls.Add(btnD5);
            Controls.Add(btnD4);
            Controls.Add(btnD3);
            Controls.Add(btnD2);
            Controls.Add(btnC5);
            Controls.Add(btnC4);
            Controls.Add(btnFree);
            Controls.Add(btnC2);
            Controls.Add(btnB5);
            Controls.Add(btnB4);
            Controls.Add(btnB3);
            Controls.Add(btnB2);
            Controls.Add(btnD1);
            Controls.Add(btnC1);
            Controls.Add(btnB1);
            Controls.Add(btnA5);
            Controls.Add(btnA4);
            Controls.Add(btnA1);
            Controls.Add(btnA2);
            Controls.Add(btnA3);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnA3;
        private Button btnA2;
        private Button btnA1;
        private Button btnA4;
        private Button btnA5;
        private Button btnB1;
        private Button btnC1;
        private Button btnD1;
        private Button btnB2;
        private Button btnB3;
        private Button btnB4;
        private Button btnB5;
        private Button btnC2;
        private Button btnFree;
        private Button btnC4;
        private Button btnC5;
        private Button btnD2;
        private Button btnD3;
        private Button btnD4;
        private Button btnD5;
        private Button btnE1;
        private Button btnE2;
        private Button btnE3;
        private Button btnE4;
        private Button btnE5;
        private Label lblCall;
        private Label lbltreats;
        private Button btnStart;
        private Button btnRestart;
        private System.Windows.Forms.Timer timer1;
    }
}