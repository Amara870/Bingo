﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Final1
{
    public partial class Form2 : Form
    {
        //Creates a list to control the buttons (array subsitute)
        List<Button> buttons;

        //Creates a random generator for the caller
        Random random = new Random();
        public Form2()
        {
            InitializeComponent();

            buttons = new List<Button> { btnA1, btnA2, btnA3, btnA4, btnA5, btnB1, btnB2, btnB3, btnB4, btnB5, btnC1, btnC2, btnFree, btnC4, btnC5, btnD1, btnD2, btnD3, btnD4, btnD5, btnE1, btnE2, btnE3, btnE4, btnE5 };

            //Disables all the playable buttons
            foreach (Button button in buttons)
            {
                button.Enabled = false;
                button.BackColor = System.Drawing.Color.White;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            //enables buttons/starts caller
            foreach (Button button in buttons)
            {
                button.Enabled = true;
            }
            
            //Function to call a selection
            Call();
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            //resets the buttons
            foreach (Button button in buttons)
            {
                button.Enabled = true;
                button.BackColor = System.Drawing.Color.White;
            }

            Call();

        }

        private void Call()
        {
            try
            {
                if (buttons.Count > 0)
                {
                    //indexes the buttons
                    int index = random.Next(buttons.Count);
                    buttons[index].Enabled = true;

                    //Displays the called button
                    lblCall.Text = $"BINGO:{buttons[index].Text}";

                    //removes the called button from the index
                    buttons.RemoveAt(index);

                }
            }
            catch (ArgumentOutOfRangeException)
            {
                //Retrys the call if it calls an index that isn't set to a button
                Call();
            }
        }

        private void Player(object sender, EventArgs e)
        {
            //Defines the button as the sender
            var button = (Button)sender;
          
            //Disables the button
            button.Enabled = false;

            //Changes the buttons color
            button.BackColor = Color.Green;

            //Calls a new selection
            Call();

            //Function to see if player won
            CheckGame();
        }

        //Checks if the player has selected 5 buttons in a row
        private void CheckGame()
        {
            int treatcount = 0;
            if(!btnA1.Enabled && !btnA2.Enabled && !btnA3.Enabled && !btnA4.Enabled && !btnA5.Enabled ||
                !btnB1.Enabled && !btnB2.Enabled && !btnB3.Enabled && !btnB4.Enabled && !btnB5.Enabled ||
                !btnC1.Enabled && !btnC2.Enabled && !btnFree.Enabled && !btnC4.Enabled && !btnC5.Enabled ||
                !btnD1.Enabled && !btnD2.Enabled && !btnD3.Enabled && !btnD4.Enabled && !btnD5.Enabled ||
                !btnE1.Enabled && !btnE2.Enabled && !btnE3.Enabled && !btnE4.Enabled && !btnE5.Enabled ||
                !btnA1.Enabled && !btnB1.Enabled && !btnC1.Enabled && !btnD1.Enabled && !btnE1.Enabled ||
                !btnA2.Enabled && !btnB2.Enabled && !btnC2.Enabled && !btnD2.Enabled && !btnE2.Enabled ||
                !btnA3.Enabled && !btnB3.Enabled && !btnFree.Enabled && !btnD3.Enabled && !btnE3.Enabled ||
                !btnA4.Enabled && !btnB4.Enabled && !btnC4.Enabled && !btnD4.Enabled && !btnE4.Enabled ||
                !btnA5.Enabled && !btnB5.Enabled && !btnC5.Enabled && !btnD5.Enabled && !btnE5.Enabled ||
                !btnA1.Enabled && !btnB2.Enabled && !btnFree.Enabled && !btnD4.Enabled && !btnE5.Enabled ||
                !btnA5.Enabled && !btnB4.Enabled && !btnFree.Enabled && !btnD2.Enabled && !btnE1.Enabled)
            {
                //Displays BINGO and win count
                lblCall.Text = "BINGO! You Won! Show this screen to the cashier to claim a free treat!";
                treatcount++;
                lbltreats.Text = $"Treats Earned: {treatcount}";
            }

            /*In real world application, the caller would call a set amount of times and the player
             would have to get a Bingo before it runs out. They'd also only be allowed to redeem one
            treat a day.*/
        }

    }
}
