﻿namespace Final1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Nametxtbox = new TextBox();
            ageTxtBox = new TextBox();
            userTxtBox = new TextBox();
            passwordTxtBox = new TextBox();
            Namelbl = new Label();
            ageLabel = new Label();
            lblUsername = new Label();
            lblPassword = new Label();
            messageLbl = new Label();
            btnSubmit = new Button();
            btnClear = new Button();
            SuspendLayout();
            // 
            // Nametxtbox
            // 
            Nametxtbox.Location = new Point(320, 90);
            Nametxtbox.Name = "Nametxtbox";
            Nametxtbox.Size = new Size(125, 27);
            Nametxtbox.TabIndex = 0;
            // 
            // ageTxtBox
            // 
            ageTxtBox.Location = new Point(320, 146);
            ageTxtBox.Name = "ageTxtBox";
            ageTxtBox.Size = new Size(125, 27);
            ageTxtBox.TabIndex = 1;
            ageTxtBox.Click += ageTxtBox_Click;
            // 
            // userTxtBox
            // 
            userTxtBox.Location = new Point(320, 200);
            userTxtBox.Name = "userTxtBox";
            userTxtBox.Size = new Size(125, 27);
            userTxtBox.TabIndex = 2;
            userTxtBox.Click += userTxtBox_Click;
            // 
            // passwordTxtBox
            // 
            passwordTxtBox.Location = new Point(320, 257);
            passwordTxtBox.Name = "passwordTxtBox";
            passwordTxtBox.Size = new Size(125, 27);
            passwordTxtBox.TabIndex = 3;
            passwordTxtBox.Click += passwordTxtBox_Click;
            // 
            // Namelbl
            // 
            Namelbl.AutoSize = true;
            Namelbl.Location = new Point(234, 97);
            Namelbl.Name = "Namelbl";
            Namelbl.Size = new Size(49, 20);
            Namelbl.TabIndex = 4;
            Namelbl.Text = "Name";
            // 
            // ageLabel
            // 
            ageLabel.AutoSize = true;
            ageLabel.Location = new Point(219, 153);
            ageLabel.Name = "ageLabel";
            ageLabel.Size = new Size(64, 20);
            ageLabel.TabIndex = 5;
            ageLabel.Text = "Birthday";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(213, 207);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(75, 20);
            lblUsername.TabIndex = 6;
            lblUsername.Text = "Username";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(213, 264);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(70, 20);
            lblPassword.TabIndex = 7;
            lblPassword.Text = "Password";
            // 
            // messageLbl
            // 
            messageLbl.AutoSize = true;
            messageLbl.Location = new Point(275, 45);
            messageLbl.Name = "messageLbl";
            messageLbl.Size = new Size(225, 20);
            messageLbl.TabIndex = 8;
            messageLbl.Text = "Create an account to play Bingo!";
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(335, 325);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(94, 29);
            btnSubmit.TabIndex = 9;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(335, 376);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(94, 29);
            btnClear.TabIndex = 10;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnClear);
            Controls.Add(btnSubmit);
            Controls.Add(messageLbl);
            Controls.Add(lblPassword);
            Controls.Add(lblUsername);
            Controls.Add(ageLabel);
            Controls.Add(Namelbl);
            Controls.Add(passwordTxtBox);
            Controls.Add(userTxtBox);
            Controls.Add(ageTxtBox);
            Controls.Add(Nametxtbox);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Nametxtbox;
        private TextBox ageTxtBox;
        private TextBox userTxtBox;
        private TextBox passwordTxtBox;
        private Label Namelbl;
        private Label ageLabel;
        private Label lblUsername;
        private Label lblPassword;
        private Label messageLbl;
        private Button btnSubmit;
        private Button btnClear;
    }
}
