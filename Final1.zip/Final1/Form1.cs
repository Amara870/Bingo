using System.Diagnostics.Eventing.Reader;

namespace Final1
{
    public partial class Form1 : Form
    {
        //Creates a file path to save the player's information
        private string filePath = "loginTracker.txt";
        public Form1()
        {
            InitializeComponent();
        }

        //Changes the text to give players a guide of how to enter their birthday
        private void ageTxtBox_Click(object sender, EventArgs e)
        {
            messageLbl.Text = "Please enter in this format: 00/00/00";
        }

        //Changes the text to give players a guide of what to input
        private void userTxtBox_Click(object sender, EventArgs e)
        {
            messageLbl.Text = "Please create a username/nickname";
        }

        //Changes the text to give players a guide on what to enter
        private void passwordTxtBox_Click(object sender, EventArgs e)
        {
            messageLbl.Text = "Please create a password";
        }

        //Submits their info to the file and opens Form2
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //FUnction to check the inputs
            CheckInput();

            //FUnction to save their infor
            CustomerAccounts();
        }

        //Checks that all the boxes are filled
        private void CheckInput ()
        {
            //Initializes the variable "name" to hold the value of the input in Name txt box
            string name = Nametxtbox.Text;

            //Initializes username variable
            string username = userTxtBox.Text;

            //Initializes password varaible
            string password = passwordTxtBox.Text;

            //Checks that all the fields are inputted
            if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(ageTxtBox.Text) && !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password))
            {
                //Show success message and opens Form2
                MessageBox.Show("Thank you for making an account!");
                Form2 form2 = new Form2();
                form2.Tag = this;
                form2.Show(this);
            }
            else
            {
                //Shows error message and prompts a fix
                MessageBox.Show("Please fill out all the boxes on the form!");
            }

            //Valiant Attempt at using a loop 

            /*List<string> txtboxes = new List<string>()
            {
              Nametxtbox.Text, passwordTxtBox.Text, ageTxtBox.Text, userTxtBox.Text
            };

           foreach (string input in txtboxes)
            {
                if (string.IsNullOrWhiteSpace(input) == true)
                {
                    MessageBox.Show("Please fill out all boxes on the form!");
                    return;
                }
                else if(string.IsNullOrWhiteSpace(input) == false)
                {
                    MessageBox.Show("Thank you for creating an account!");
                    return;
                }
            }*/

        }

        //Clears input fields allowing user to start over
        private void btnClear_Click(object sender, EventArgs e)
        {
            //Function to clear everything at once
            Clear();
        }

        //Functon to clear everything at once
        private void Clear ()
        {
            //Clears naem txt box
            Nametxtbox.Clear();

            //Clears age txt box
            ageTxtBox.Clear();

            //Clears username txt box
            userTxtBox.Clear();

            //Clears password txt box
            passwordTxtBox.Clear();
        }

        //Function to creat the user's account
        private void CustomerAccounts()
        {
            try
            {
                //Checks if the account save file exists
            if(File.Exists(filePath))
            {
                    //Checks if the user already has an account
                if(!File.ReadAllText(filePath).Contains(userTxtBox.Text));
                    {
                        //Saves account info to the file
                        File.AppendAllText(filePath, userTxtBox.Text);
                        File.AppendAllText(filePath, passwordTxtBox.Text);
                        File.AppendAllText(filePath, ageTxtBox.Text);
                        File.AppendAllText(filePath, Nametxtbox.Text);
                    }
                if (File.ReadAllText(filePath).Contains(userTxtBox.Text));
                    {
                        MessageBox.Show("We found your account. Enjoy the game!");
                    }

                }
            }

            //Handles the exception if the file doesn't existtrac
            catch (FileNotFoundException)
            {
                MessageBox.Show("Sorry, we couldn't save your account information. Enjoy the game!");
                Form2 form2 = new Form2();
                form2.Tag = this;
                form2.Show(this);
            }
        }
    }
}
